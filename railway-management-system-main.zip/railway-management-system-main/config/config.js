module.exports = {
  db: {
    host: "localhost",
    user: "root",
    password: "root123",
    database: "railway_management",
  },
  port: process.env.PORT || 3000,
};
